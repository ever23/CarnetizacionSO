<?php

return [
    'class' => '\\Cc\\Mvc\\MySQLi',
    'param' => ['localhost', 'root', '', 'CarnetizacionSO']
];

/**
 * return [
 *  'class' => '\\Cc\\Mvc\\MySQLi',
 *  'param' => ['localhost', 'tu Usuario', 'Tu contraseña', 'CarnetizacionSO']
 * ];
 *
 */